package com.msf.studenttask.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import com.msf.studenttask.entity.Student;
import com.msf.studenttask.service.impl.StudentServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import java.util.ArrayList;
import java.util.List;


import static org.mockito.Mockito.*;

class StudentControllerTest {

    @InjectMocks
    private StudentController studentController;

    @Mock
    private StudentServiceImpl studentServiceImpl;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllStudents() {
        List<Student> students = new ArrayList<>();
        students.add(new Student(1, "Sree", 21, "A+"));
        students.add(new Student(2, "Sreehitha", 21, "A"));

        when(studentServiceImpl.getAllStudents()).thenReturn(students);

        ResponseEntity<List<Student>> responseEntity = studentController.getAllStudents();

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(2, responseEntity.getBody().size());
    }

    @Test
    void testGetStudentById() {
        Student student = new Student(1, "Sree", 21, "A");

        when(studentServiceImpl.getStudentById(1)).thenReturn(student);
        when(studentServiceImpl.getStudentById(100)).thenReturn(null);

        ResponseEntity<Student> responseEntityFound = studentController.getStudentById(1);
        ResponseEntity<Student> responseEntityNotFound = studentController.getStudentById(100);

        assertEquals(HttpStatus.OK, responseEntityFound.getStatusCode());
        assertEquals("Sree", responseEntityFound.getBody().getName());

        assertEquals(HttpStatus.NOT_FOUND, responseEntityNotFound.getStatusCode());
    }

    @Test
    void testSearchStudents() {
        List<Student> students = new ArrayList<>();
        students.add(new Student(1, "Sree", 21, "A+"));
        students.add(new Student(2, "Sreehitha", 21, "A"));

        when(studentServiceImpl.searchStudentsByName("Sree")).thenReturn(students);

        ResponseEntity<List<Student>> responseEntity = studentController.searchStudents("Sree");

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(2, responseEntity.getBody().size());
    }

    @Test
    void testGetAllStudentsSortedByGrade() {
        List<Student> students = new ArrayList<>();
        students.add(new Student(1, "Sree", 21, "A+"));
        students.add(new Student(2, "Sreehitha", 21, "A"));

        when(studentServiceImpl.getAllStudentsSortedByGrade()).thenReturn(students);

        ResponseEntity<List<Student>> responseEntity = studentController.getAllStudentsSortedByGrade();

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(2, responseEntity.getBody().size());
    }

    @Test
    void testAddStudent() {
        Student student = new Student(1, "Sree", 21, "A+");

        when(studentServiceImpl.saveStudent(any())).thenReturn(student);

        ResponseEntity<Student> responseEntity = studentController.addStudent(student);

        assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
        assertEquals(1, responseEntity.getBody().getId());
        assertEquals("Sree", responseEntity.getBody().getName());
    }

    @Test
    void testDeleteStudent() {
        ResponseEntity<Void> responseEntity = studentController.deleteStudent(1);

        assertEquals(HttpStatus.NO_CONTENT, responseEntity.getStatusCode());
        verify(studentServiceImpl, times(1)).deleteStudent(1);
    }
}
