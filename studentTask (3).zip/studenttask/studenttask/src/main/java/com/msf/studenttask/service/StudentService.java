package com.msf.studenttask.service;

import com.msf.studenttask.entity.Student;

import java.util.List;

public interface StudentService {
    List<Student> getAllStudents();
    Student getStudentById(int id);
    List<Student> searchStudentsByName(String name);
    List<Student> getAllStudentsSortedByGrade();
    Student saveStudent(Student student);
    void deleteStudent(int id);






}

