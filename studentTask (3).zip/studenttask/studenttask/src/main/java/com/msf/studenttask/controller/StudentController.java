package com.msf.studenttask.controller;

import com.msf.studenttask.entity.Student;
import com.msf.studenttask.service.impl.StudentServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {

        @Autowired
        StudentServiceImpl studentServiceImpl;
        @GetMapping
        public ResponseEntity<List<Student>> getAllStudents() {
            List<Student> students = studentServiceImpl.getAllStudents();
            return new ResponseEntity<>(students, HttpStatus.OK);
        }
        @GetMapping("/{id}")
        public ResponseEntity<Student> getStudentById(@PathVariable int id) {
            Student student = studentServiceImpl.getStudentById(id);
            if (student != null) {
                return new ResponseEntity<>(student, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        }
        @GetMapping("/search")
        public ResponseEntity<List<Student>> searchStudents(@RequestParam String name)
        {
            List<Student> students;

            if (name != null) {
                students = studentServiceImpl.searchStudentsByName(name);
            } else {
                students = studentServiceImpl.getAllStudents();
            }

            return new ResponseEntity<>(students, HttpStatus.OK);
        }
        @GetMapping("/sort-by-grade")
        public ResponseEntity<List<Student>> getAllStudentsSortedByGrade() {
            List<Student> students = studentServiceImpl.getAllStudentsSortedByGrade();
            return new ResponseEntity<>(students, HttpStatus.OK);
        }
        @PostMapping
        public ResponseEntity<Student> addStudent(@RequestBody Student student) {
            Student savedStudent = studentServiceImpl.saveStudent(student);
            return new ResponseEntity<>(savedStudent, HttpStatus.CREATED);
        }
        @DeleteMapping("/{id}")
        public ResponseEntity<Void> deleteStudent(@PathVariable int id) {
            studentServiceImpl.deleteStudent(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
}
