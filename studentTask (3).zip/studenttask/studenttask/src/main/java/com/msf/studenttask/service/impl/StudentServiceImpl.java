package com.msf.studenttask.service.impl;

import com.msf.studenttask.entity.Student;
import com.msf.studenttask.repository.StudentRepository;
import com.msf.studenttask.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentService
{
    private final StudentRepository studentRepository;

    @Autowired
    public StudentServiceImpl(StudentRepository studentRepository)
    {
        this.studentRepository = studentRepository;
    }
        public List<Student> getAllStudents() {
            return studentRepository.findAll();
        }

        public Student getStudentById(int id) {
            return studentRepository.findById(id)
                    .orElse(null);
        }

        public List<Student> searchStudentsByName(String name) {
            return studentRepository.findByName(name);
        }


        public List<Student> getAllStudentsSortedByGrade() {
            return studentRepository.findAll(Sort.by(Sort.Direction.ASC, "grade"));
        }

        public Student saveStudent(Student student) {
            return studentRepository.save(student);
        }

        public void deleteStudent(int id) {
            studentRepository.deleteById(id);
        }

}
