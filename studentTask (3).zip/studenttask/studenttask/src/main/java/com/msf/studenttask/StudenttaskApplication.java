package com.msf.studenttask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudenttaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudenttaskApplication.class, args);
	}

}
